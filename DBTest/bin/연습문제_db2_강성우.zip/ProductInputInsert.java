package db2;

public class ProductInputInsert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
